/* Configuration header created by Waf - do not edit */
#ifndef _CONFIG_H_WAF
#define _CONFIG_H_WAF

#define HAVE_OPENSSL 1
#define HAVE_V8_H 1
#define HAVE_ARES_H 1
#define HAVE_EV_H 1
#define HAVE_CONFIG_H 1
#endif /* _CONFIG_H_WAF */
